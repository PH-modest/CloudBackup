1. env
system: >=ubuntu20.04
ceres:  sudo apt install libceres-dev


2. build
mkdir build
cd build
cmake ..
make

3. run
cd build
./lsacalib

4. run your data
modify lsa_calib.cpp line 118 to set filder path