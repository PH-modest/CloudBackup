#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <Eigen/Dense>
#include <ceres/ceres.h>
#include <ceres/rotation.h>

using namespace std;
using namespace Eigen;

// ------------------- 读取txt -------------------
struct Pose {
    Matrix4d T;      // 手末到基坐标
    Vector3d XS;     // 球心
};

Pose read_pose(const string &file){
    std::cout<<file<<std::endl;
    ifstream fin(file);
    if(!fin.is_open()) throw runtime_error("File not exist: "+file);

    vector<double> data;
    double val;
    while(fin >> val) data.push_back(val);
    if(data.size() < 9) throw runtime_error("File format error: "+file);

    Vector3d t(data[0], data[1], data[2]);
    Vector3d euler(data[3], data[4], data[5]);

    Matrix3d R = AngleAxisd(euler[2]*M_PI/180.0, Vector3d::UnitZ()).toRotationMatrix()
               * AngleAxisd(euler[1]*M_PI/180.0, Vector3d::UnitY()).toRotationMatrix()
               * AngleAxisd(euler[0]*M_PI/180.0, Vector3d::UnitX()).toRotationMatrix();

    Matrix4d T = Matrix4d::Identity();
    T.block<3,3>(0,0) = R;
    T.block<3,1>(0,3) = t;

    Vector3d XS(data[6], data[7], data[8]);

    return {T, XS};
}

// ------------------- 旋转残差 -------------------
struct RotateResidual{
    RotateResidual(const MatrixXd &A_, const VectorXd &b1_, const VectorXd &b2_, const VectorXd &b3_)
        : A(A_), b1(b1_), b2(b2_), b3(b3_) {}

    template<typename T>
    bool operator()(const T* const q, T* residual) const{
        // 四元数归一化
        T qn[4] = {q[0],q[1],q[2],q[3]};
        T norm = ceres::sqrt(qn[0]*qn[0]+qn[1]*qn[1]+qn[2]*qn[2]+qn[3]*qn[3]);
        for(int i=0;i<4;i++) qn[i]/=norm;

        // quaternion -> rotation matrix
        T R_arr[9];
        ceres::QuaternionToRotation(qn,R_arr);
        Matrix<T,3,3> Rs;
        Rs << R_arr[0],R_arr[1],R_arr[2],
              R_arr[3],R_arr[4],R_arr[5],
              R_arr[6],R_arr[7],R_arr[8];

        Matrix<T,3,3> Rt = Rs.transpose();

        Matrix<T,3,1> X1 = Rt.col(0);
        Matrix<T,3,1> X2 = Rt.col(1);
        Matrix<T,3,1> X3 = Rt.col(2);

        Matrix<T,6,1> temp1 = A.cast<T>()*X1 - b1.cast<T>();
        Matrix<T,6,1> temp2 = A.cast<T>()*X2 - b2.cast<T>();
        Matrix<T,6,1> temp3 = A.cast<T>()*X3 - b3.cast<T>();

        for(int i=0;i<6;i++) residual[i] = temp1(i);
        for(int i=0;i<6;i++) residual[i+6] = temp2(i);
        for(int i=0;i<6;i++) residual[i+12] = temp3(i);

        return true;
    }

    const MatrixXd &A;
    const VectorXd &b1, &b2, &b3;
};

// ------------------- 平移残差 -------------------
struct TranslationResidual{
    TranslationResidual(const vector<Matrix3d> &R_prev_, const vector<Matrix3d> &R_curr_,
                        const vector<Vector3d> &XS_prev_, const vector<Vector3d> &XS_curr_,
                        const vector<Vector3d> &T_prev_, const vector<Vector3d> &T_curr_,
                        const Matrix3d &R_opt_)
        : R_prev(R_prev_), R_curr(R_curr_), XS_prev(XS_prev_), XS_curr(XS_curr_),
          T_prev(T_prev_), T_curr(T_curr_), R_opt(R_opt_) {}

    template<typename T>
    bool operator()(const T* const t, T* residual) const{
        Matrix<T,3,1> Ts; Ts << t[0],t[1],t[2];

        for(size_t i=0;i<R_prev.size();i++){
            Matrix<T,3,3> Ri = (R_curr[i]-R_prev[i]).cast<T>();
            Matrix<T,3,3> E = Matrix<T,3,3>::Identity()*1e-8;
            Matrix<T,3,1> Xi = (R_prev[i].cast<T>()*R_opt.cast<T>()*XS_prev[i].cast<T>() 
                                - R_curr[i].cast<T>()*R_opt.cast<T>()*XS_curr[i].cast<T>()) 
                                + (T_prev[i].cast<T>() - T_curr[i].cast<T>());
            Matrix<T,3,1> res = (Ri.transpose()*Ri + E)*Ts - Ri.transpose()*Xi;
            for(int j=0;j<3;j++) residual[3*i+j] = res(j);
        }
        return true;
    }

    const vector<Matrix3d> R_prev, R_curr;
    const vector<Vector3d> XS_prev, XS_curr;
    const vector<Vector3d> T_prev, T_curr;
    const Matrix3d R_opt;
};

int main(){
    // ---------- 读取数据 ----------
    string path = "../data3";
    vector<Pose> poses;
    for(int i=0;i<8;i++) poses.push_back(read_pose(path+"/"+to_string(i+1)+".txt"));

    for(int i=0;i<8;i++) std::cout<<poses[i].XS<<"\n"<<poses[i].T<<std::endl;

    vector<Vector3d> ts;
    for(int i=0;i<8;i++) ts.push_back(poses[i].T.block<3,1>(0,3));

    MatrixXd XS_difference(3,6);
    XS_difference.col(0) = poses[0].XS - poses[1].XS;
    XS_difference.col(1) = poses[0].XS - poses[2].XS;
    XS_difference.col(2) = poses[0].XS - poses[3].XS;
    XS_difference.col(3) = poses[1].XS - poses[2].XS;
    XS_difference.col(4) = poses[1].XS - poses[3].XS;
    XS_difference.col(5) = poses[2].XS - poses[3].XS;

    // 拼接 T0_difference (3,6)
    MatrixXd T0_difference(3,6);
    T0_difference.col(0) = ts[1] - ts[0];
    T0_difference.col(1) = ts[2] - ts[0];
    T0_difference.col(2) = ts[3] - ts[0];
    T0_difference.col(3) = ts[2] - ts[1];
    T0_difference.col(4) = ts[3] - ts[1];
    T0_difference.col(5) = ts[3] - ts[2];

    VectorXd XS_norms(6), T_norms(6);
    for(int i=0; i<6; i++) {
        XS_norms(i) = XS_difference.col(i).norm();
        T_norms(i) = T0_difference.col(i).norm();
    }

    cout << "XS norms: " << XS_norms.transpose() << endl;
    cout << "T norms: " << T_norms.transpose() << endl;

    // 构造 A 矩阵 (6,3)
    MatrixXd A = XS_difference.transpose();
    cout << "A =\n" << A << endl;

    // 提取旋转矩阵
    Matrix3d R0 = poses[0].T.block<3,3>(0,0);
    // Matrix3d R05 = HB_all[4].block<3,3>(0,0);
    // Matrix3d R06 = HB_all[5].block<3,3>(0,0);
    // Matrix3d R07 = HB_all[6].block<3,3>(0,0);
    // Matrix3d R08 = HB_all[7].block<3,3>(0,0);

    cout << "R0 =\n" << R0 << endl;

    // b = (R0^T * T0_difference)^T
    MatrixXd b = (R0.transpose() * T0_difference).transpose();

    // 分离列向量 b1,b2,b3
    VectorXd b1 = b.col(0);
    VectorXd b2 = b.col(1);
    VectorXd b3 = b.col(2);

    cout << "b1 =\n" << b1 << endl;
    cout << "b2 =\n" << b2 << endl;
    cout << "b3 =\n" << b3 << endl;

    double q[4]={0,0,0,1};
    ceres::Problem problem_q;
    problem_q.AddResidualBlock(
        new ceres::AutoDiffCostFunction<RotateResidual,18,4>(
            new RotateResidual(A,b1,b2,b3)
        ),nullptr,q
    );
    ceres::Solver::Options options_q;
    options_q.trust_region_strategy_type = ceres::LEVENBERG_MARQUARDT;
    options_q.linear_solver_type = ceres::DENSE_QR;
    options_q.minimizer_progress_to_stdout = true;
    ceres::Solver::Summary summary_q;
    ceres::Solve(options_q,&problem_q,&summary_q);
    cout<<"Quaternion: ["<<q[0]<<","<<q[1]<<","<<q[2]<<","<<q[3]<<"]"<<endl;

    Matrix3d R_opt;
    ceres::QuaternionToRotation(q,R_opt.data());
    std::cout<<R_opt<<std::endl;

    // ---------- 构造平移残差 ----------
    // 对应 Python R05~R08, XS5~XS8, T05~T08
    vector<Matrix3d> R_prev,R_curr;
    vector<Vector3d> XS_prev, XS_curr;
    vector<Vector3d> T_prev, T_curr;
    int idx[6][2]={{5,4},{6,5},{7,6},{6,4},{7,4},{7,5}};
    for(int i=0;i<6;i++){
        int a=idx[i][0],b=idx[i][1];
        R_prev.push_back(poses[b].T.block<3,3>(0,0));
        R_curr.push_back(poses[a].T.block<3,3>(0,0));
        XS_prev.push_back(poses[b].XS);
        XS_curr.push_back(poses[a].XS);
        T_prev.push_back(poses[b].T.block<3,1>(0,3));
        T_curr.push_back(poses[a].T.block<3,1>(0,3));
    }

    double t[3]={0,0,0};
    ceres::Problem problem_t;
    problem_t.AddResidualBlock(
        new ceres::AutoDiffCostFunction<TranslationResidual,18,3>(
            new TranslationResidual(R_prev,R_curr,XS_prev,XS_curr,T_prev,T_curr,R_opt)
        ),nullptr,t
    );
    ceres::Solver::Options options_t;
    options_t.trust_region_strategy_type = ceres::LEVENBERG_MARQUARDT;
    options_t.linear_solver_type = ceres::DENSE_QR;
    options_t.minimizer_progress_to_stdout = true;
    ceres::Solver::Summary summary_t;
    ceres::Solve(options_t,&problem_t,&summary_t);
    cout<<"Translation: ["<<t[0]<<","<<t[1]<<","<<t[2]<<"]"<<endl;

    // ---------- 球心计算 ----------
    Matrix4d RT = Matrix4d::Identity();
    RT.block<3,3>(0,0) = R_opt;
    RT.block<3,1>(0,3) << t[0], t[1], t[2];

    vector<Vector3d> points;
    for(auto &p: poses){
        Vector4d pt = p.T*RT*Vector4d(p.XS(0),p.XS(1),p.XS(2),1);
        points.push_back(pt.head<3>());
    }

    int N = points.size();
    Eigen::MatrixXd point_all(N, 3);
    for(int i = 0; i < N; ++i){
        point_all.row(i) = points[i].transpose();
    }

    Eigen::RowVector3d mean = point_all.colwise().mean();
    Eigen::RowVector3d var = Eigen::RowVector3d::Zero();
    for(int j = 0; j < 3; ++j){
        var(j) = (point_all.col(j).array() - mean(j)).square().sum() / N;
    }
    Eigen::RowVector3d std = var.array().sqrt();
    cout << "Ball center mean     : " << mean << endl;
    cout << "Ball center variance : " << var << endl;
    cout << "Ball center std      : " << std << endl;


    // Vector3d avg = Vector3d::Zero();
    // for(auto &pt: points) avg += pt;
    // avg/=points.size();
    // cout<<"Average ball center: "<<avg.transpose()<<endl;

    // for(size_t i=0;i<points.size();i++){
    //     Vector3d diff = points[i]-avg;
    //     cout<<i+1<<"th ball center error: "<<diff.transpose()<<endl;
    // }

    return 0;
}
